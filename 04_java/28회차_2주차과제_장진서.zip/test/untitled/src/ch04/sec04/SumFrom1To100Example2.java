package ch04.sec04;

public class SumFrom1To100Example2 {
    public static void main(String[] args) {
        int x = 0;
        int i = 0;
        while(i <= 100) {
            x += i;
            i++;
        }

        System.out.println("1~"+ (i-1) +" 합 : " + x);
    }
}
