package org.edu.ex03;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet(value = "/sports")
public class SportsServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        req.setCharacterEncoding("UTF-8");
        resp.setContentType("text/html;charset=UTF-8");

        String[] sports = req.getParameterValues("sports");
        String sex = req.getParameter("sex");

        PrintWriter out = resp.getWriter();

        out.println("<html><body>");

        if(sports != null){
            for(String s : sports){
                out.println("<p>좋아하는 운동 : " + s + "</p>");
            }
        }else{
            out.println("<p>좋아하는 운동: 없음</p>");
        }

        out.println("<p>성별 : " + sex + "</p>");
        out.println("</body></html>");
    }
}
